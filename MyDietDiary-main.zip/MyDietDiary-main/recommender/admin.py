from django.contrib import admin
from recommender.models import Food
# Register your models here.
admin.site.register(Food)